<?php
	$con = mysqli_connect('localhost', 'root');
	if($con) {
		echo "Connection Successful";
	}
	else{
		echo "Connection Failed";
	}

	mysqli_select_db($con, 'wondertour');

	$name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $message = $_POST['message'];

	$query = "INSERT INTO contactus (name, email, phone, message) VALUES ('$name','$email', '$phone', '$message')"; 
	mysqli_query($con, $query);
	header('location:index.html');
?>